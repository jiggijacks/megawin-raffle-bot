# This file is disabled because FastAPI app is in bot.py
# The webserver.py file is kept for reference or future use.